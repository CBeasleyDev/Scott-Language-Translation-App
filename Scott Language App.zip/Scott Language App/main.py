# Scott is a language translator developed by Christian Beasley
# The idea of Scott is to foster communication among diverse groups


import tkinter as tk
from googletrans import Translator

class MyLanguage:
    def __init__(self, source_lang, target_lang):

        self.source_lang = source_lang
        self.target_lang = target_lang
        self.translator = Translator()

    def translate_text(self, phrase, target_lang):
        translation = self.translator.translate(phrase, src=self.source_lang, dest=target_lang)
        return translation.text

class TranslatorApp:
    def __init__(self, master):

        self.master = master
        self.master.title("Scott")

        self.my_language = MyLanguage("en", "es")  # Default source and target languages

        # Create GUI elements
        self.label_source = tk.Label(master, text="Enter text to translate:")
        self.entry_source = tk.Entry(master, width=50)
        self.label_target = tk.Label(master, text="Translated text:")
        self.text_target = tk.Text(master, height=5, width=50, state=tk.DISABLED)
        self.button_translate = tk.Button(master, text="Translate", command=self.translate_text)
        self.button_change_lang = tk.Button(master, text="Change Target Language", command=self.change_target_language)

        # Arrange GUI elements
        self.label_source.grid(row=0, column=0, padx=10, pady=10, columnspan=2)
        self.entry_source.grid(row=1, column=0, padx=10, pady=10, columnspan=2)
        self.button_translate.grid(row=2, column=0, pady=10, columnspan=2)
        self.label_target.grid(row=3, column=0, padx=10, pady=10, columnspan=2)
        self.text_target.grid(row=4, column=0, padx=10, pady=10, columnspan=2)
        self.button_change_lang.grid(row=5, column=0, pady=10, columnspan=2)

    def translate_text(self):

        source_text = self.entry_source.get()
        target_text = self.my_language.translate_text(source_text, self.my_language.target_lang)
        self.text_target.config(state=tk.NORMAL)
        self.text_target.delete(1.0, tk.END)
        self.text_target.insert(tk.END, target_text)
        self.text_target.config(state=tk.DISABLED)

    def change_target_language(self):
        new_target_lang = input("Enter new target language code: ")
        self.my_language.target_lang = new_target_lang

if __name__ == "__main__":
    root = tk.Tk()
    app = TranslatorApp(root)
    root.mainloop()